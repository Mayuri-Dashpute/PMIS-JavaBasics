package com.StudentManagement.entity;

/*
 * Student Entity
 *
 * This class represents a student.
 * It contains student details such as
 * id, name, email and course.
 */

public class Student {

    private Long id;
    private String name;
    private String email;
    private String course;

    public Student() {
    }

    public Student(Long id, String name,
                   String email, String course) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.course = course;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }
}
